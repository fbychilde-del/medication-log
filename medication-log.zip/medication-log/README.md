# 服药记录（Android + 原有 PWA）

基于上一版增量修改；应用名「服药记录」，包名 `com.medicationlog.app`。
保留原生 HTML/CSS/JS、IndexedDB、所有记录操作与 JSON 备份。图表使用 SVG/CSS，无图表依赖。

## 安装 APK

如果下载中提供 APK，复制到 Android 手机，点击并允许当前文件管理器安装即可。要求 Android 7.0 或以上，Android System WebView 需保持更新。首次启动即可离线使用，无需部署网站。

**迁移旧记录：先在原 PWA 中导出 JSON，再在新 App 中导入。** 浏览器与 App 存储相互独立，不会自动迁移。JSON 格式、数据库名称 `medication-log`、版本 1、`medicines` / `records` 表和字段保持不变。

## 构建 APK（Android Studio）

安装 Node.js 22+ 和 Android Studio 2025.2.1 或更新版本。Android SDK Manager 中安装 Android SDK Platform 36、Build-Tools 36.0.0；Gradle JDK 选择 JDK 21（可使用 Studio 自带的兼容 JDK）。

在本项目目录执行：

```sh
npm ci
npm run sync
```

在 Android Studio 打开 `android` 文件夹，等待 Gradle 同步。菜单 Build → Generate App Bundles or APKs → Generate APKs（部分版本为 Build APK(s)）。生成文件：

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

或设置好 `JAVA_HOME`（JDK 21）和 `ANDROID_HOME`（Android SDK 目录）后运行：

```sh
npm run apk
```

无须再次执行 `cap add android`，原生工程已经包含。首次构建需要网络下载 npm、Gradle 和 Android 依赖。

调试 APK 可直接安装，适合自己使用。正式发布可在 Android Studio 使用 Generate Signed Bundle / APK，并自行创建、保存签名密钥。后续更新必须保持包名和签名一致；不要为了更新而卸载，以免清除本地数据。

## 本次修改

- 顶部：最近 7 天、30 天次数，以及连续记录天数。每天至少一条记录；今天暂无记录时，从昨天开始计算连续天数。
- 七天时间散点图：按本地日期与时间展示，每条记录一个点；点按可查看详情。同一分钟的多个点横向错开，纵向时间保持不变。
- 横向柱状图：按药名合并计数，跟随 7 天 / 30 天 / 全部范围选择。保留环形平均服药时间。
- 启动页：原 App 图标，背景 `#f5f7f6`，首次数据渲染后淡出约 160 ms；异常时 4 秒兜底。具体启动表现仍受 Android 版本和桌面影响。
- Android 导出：使用系统“保存文件”窗口，无存储权限；导入沿用系统文件选择与原 JSON 校验合并逻辑。
- Android 不注册 Service Worker，程序文件随 APK 打包；PWA 继续支持 Service Worker。

## 本地数据

普通关闭、重启后 IndexedDB 保留；卸载、清除应用数据会丢失，请定期导出备份。相同 ID 的导入保留本机版本。Android 自动备份已关闭，应用不提供云同步。备份文件位置由你选择。

## 继续运行 PWA

```sh
npm ci
npm run build
python3 -m http.server 8080 --directory www
```

电脑打开 http://localhost:8080。部署时上传 `www` 中全部文件到原 HTTPS 地址。保留原域名和路径可继续使用原浏览器的数据。修改页面后运行 `npm run sync` 再打包；更新 PWA 时递增 `sw.js` 缓存版本。

依赖与启动配置参考：https://capacitorjs.com/docs 、https://capacitorjs.com/docs/apis/splash-screen 。
