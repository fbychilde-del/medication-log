import { spawnSync } from 'node:child_process';
const win = process.platform === 'win32';
const result = spawnSync(win ? 'cmd.exe' : 'sh', win ? ['/c', 'gradlew.bat', 'assembleDebug'] : ['./gradlew', 'assembleDebug'], { cwd: new URL('../android/', import.meta.url), stdio:'inherit' });
if (result.error) console.error(result.error.message);
process.exit(result.status ?? 1);
