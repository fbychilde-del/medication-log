import { mkdir, rm, copyFile, cp } from 'node:fs/promises';
import { build } from 'esbuild';
const root = new URL('../', import.meta.url);
const www = new URL('www/', root);
await rm(www, { recursive: true, force: true });
await mkdir(www, { recursive: true });
for (const file of ['index.html','style.css','app.js','sw.js','manifest.webmanifest']) {
  await copyFile(new URL(file, root), new URL(file, www));
}
await cp(new URL('icons/', root), new URL('icons/', www), {recursive:true});
await build({ entryPoints: [new URL('native.js', root).pathname], bundle: true, format: 'iife', target: 'es2020', outfile: new URL('native-bridge.js', www).pathname, minify:true });
console.log('Web assets built in www/');
// Keep the original flat PWA directory runnable as well.
await copyFile(new URL('native-bridge.js', www), new URL('native-bridge.js', root));
