import { Capacitor, registerPlugin } from '@capacitor/core';
import { SplashScreen } from '@capacitor/splash-screen';
const Backup = registerPlugin('Backup');
window.MedicationNative = {
  isNative: Capacitor.isNativePlatform(),
  exportBackup: options => Backup.save(options),
  ready: async () => {
    if (!Capacitor.isNativePlatform()) return;
    // Let the first populated frame reach the WebView before fading the splash.
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
    await SplashScreen.hide({ fadeOutDuration: 160 });
  }
};
// A database error must not leave the user trapped on the launch screen.
if (Capacitor.isNativePlatform()) setTimeout(() => SplashScreen.hide().catch(console.error), 4000);
