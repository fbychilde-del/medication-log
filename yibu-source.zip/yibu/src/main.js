import './style.css';
import { uid, localDate, addDays, dateLabel, initialState, visibleTasks, countdown, weekStats, weeks, summaryText, remainingMs, finishTimer, FOCUS_MS, exportBackup, parseBackup } from './core.js';
import { openStore, save, get, acquireLock } from './storage.js';
import { native, permission, syncReminders, exactStatus, requestExact, focusNotification, notifyNow, exportFile, initNative } from './native.js';

const app=document.querySelector('#app');
const modal=document.querySelector('#modal');
const paths={
  step:'M4 19h6v-6h6V7h5M5 5h.01',
  sun:'M12 3v2m0 14v2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M5.6 18.4 7 17M17 7l1.4-1.4M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0',
  book:'M4 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-2H4zm16 0h-4a3 3 0 0 0-3 3v14a4 4 0 0 1 4-2h3z',
  chart:'M4 4v16h17M8 15l4-5 4 2 5-7',
  settings:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1z',
  plus:'M12 5v14M5 12h14', arrow:'M5 12h14m-5-5 5 5-5 5', check:'m5 12 4 4L19 6',
  clock:'M12 8v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0',
  play:'m9 5 11 7-11 7z', pause:'M8 5v14M16 5v14', reset:'M4 10a8 8 0 1 1 1 8M4 4v6h6',
  edit:'m16 3 5 5-12 12H4v-5zM13 6l5 5', trash:'M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7',
  close:'m6 6 12 12M6 18 18 6', download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',
  upload:'M12 16V4m-5 5 5-5 5 5M4 16v5h16v-5', shield:'m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6zm-4 9 3 3 5-6',
  bell:'M6 9a6 6 0 0 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9m4 12h4', leaf:'M20 3C8 2 2 8 5 15s14 4 15-12ZM4 21l10-11',
  calendar:'M5 5h14a2 2 0 0 1 2 2v13H3V7a2 2 0 0 1 2-2m2-3v6m10-6v6M3 11h18', copy:'M9 8h12v13H9zM5 16H3V3h12v2',
  spark:'m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3z', offline:'M4 11a12 12 0 0 1 16 0M7 14a8 8 0 0 1 10 0m-7 3a3 3 0 0 1 4 0m-2 3h.01',
};
const icon=(name,cls='')=>`<svg class="icon ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]||paths.step}"/></svg>`;
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const nav=[['tasks','sun','今日行动'],['logs','book','研究日志'],['progress','chart','三周进度'],['settings','settings','设置与备份']];
const priority={high:'优先做',medium:'按计划',low:'慢慢来'};
let state, route='tasks', tab='today', logFilter='all', selectedTask='', queue=Promise.resolve(), ticking=false, installPrompt, waitingWorker, toastTimeout, ready=false, exact=false, notificationsGranted=false, persistent=false, shellCached=false;
let restoreCandidate=null;

function toast(message, action, label='撤销') {
  const el=document.querySelector('#toast');
  el.replaceChildren(document.createTextNode(message));
  if(action) { const b=document.createElement('button'); b.textContent=label; b.onclick=()=>{el.classList.remove('show');void action();}; el.append(b); }
  el.classList.add('show'); clearTimeout(toastTimeout); toastTimeout=setTimeout(()=>el.classList.remove('show'),6500);
}
function report(error) { console.error(error); toast(error.message || '操作未完成，请再试一次。'); }
function mutate(change,{recovery,renderAfter=true}={}) {
  const run=queue.then(async()=>{
    const next=structuredClone(state); change(next);
    await save(next,recovery); state=next;
    if(renderAfter) render();
  });
  queue=run.catch(()=>{});
  return run;
}
function go(next) { if(!nav.some(n=>n[0]===next)) return; route=next; render(); window.scrollTo({top:0,behavior:'instant'}); }
function countdownText(c) { return c.remaining>0 ? `还有 <strong>${c.remaining}</strong> 天` : c.remaining===0 ? '<strong>今天</strong> 展示进展' : `已到期 <strong>${Math.abs(c.remaining)}</strong> 天`; }

function render() {
  if(!ready) return;
  const today=localDate(), stats=weekStats(state,today,today), c=countdown(state.settings);
  const date=new Date().toLocaleDateString('zh-CN',{month:'long',day:'numeric',weekday:'long'});
  app.innerHTML=`
    <aside class="sidebar">
      <a class="brand" href="#" data-action="home" aria-label="一步首页"><span class="brand-mark">${icon('step')}</span><span>一步<small>让研究向前一点</small></span></a>
      <span class="nav-caption">我的研究空间</span>
      <nav aria-label="主导航">${nav.map(([key,i,label])=>`<button class="nav-item ${route===key?'active':''}" data-action="nav" data-route="${key}" ${route===key?'aria-current="page"':''}>${icon(i)}<span>${label}</span>${route===key?'<i></i>':''}</button>`).join('')}</nav>
      <div class="sidebar-note"><div class="tiny-flower">✳</div><p>不必一次走很远。<br>今天，向前一点就好。</p><span>每一步，都算数。</span></div>
      <button class="local-status" data-action="nav" data-route="settings">${icon('shield')}<span>数据只在你的设备上</span></button>
    </aside>
    <div class="workspace">
      <header class="topbar"><div><span class="mobile-brand">${icon('step')} 一步</span><span class="breadcrumb">我的研究空间 <span>/</span> ${nav.find(n=>n[0]===route)[2]}</span></div><div class="top-actions"><span class="online-dot ${navigator.onLine?'':'offline'}"></span><span>${navigator.onLine?'本地保存':'离线使用'}</span><button class="icon-button" data-action="nav" data-route="settings" aria-label="提醒设置">${icon('bell')}</button><span class="avatar" aria-label="研究者">研</span></div></header>
      ${waitingWorker?'<div class="update-banner">新版本已准备好，记录会保留。<button data-action="update">更新一步</button></div>':''}
      <main id="main" tabindex="-1">
        ${route==='tasks'?taskPage(date,today,stats,c):route==='logs'?logsPage():route==='progress'?progressPage(c):settingsPage()}
      </main>
      <footer class="page-footer"><span>一步 YIBU</span><span>认真记录，慢慢向前。</span></footer>
    </div>
    <nav class="mobile-nav" aria-label="手机导航">${nav.map(([key,i,label])=>`<button data-action="nav" data-route="${key}" class="${route===key?'active':''}" ${route===key?'aria-current="page"':''}>${icon(i)}<span>${label==='设置与备份'?'设置':label}</span></button>`).join('')}</nav>`;
  updateClock();
}
function taskPage(date,today,stats,c) {
  const items=visibleTasks(state,tab);
  const open=state.tasks.filter(t=>!t.completedAt);
  const next=visibleTasks(state,'today')[0] || open[0];
  return `<div class="page-heading"><div><p class="eyebrow">${date} <span>· 新的一步</span></p><h1>先做一件，小事也算<span class="orange">。</span></h1><p class="subtitle">把很远的目标，变成今天可以开始的一步。</p></div><button class="button primary heading-button" data-action="add-task">${icon('plus')} 添加任务</button></div>
    <div class="dashboard-grid"><div class="main-column">
      <section class="plan-banner" aria-label="研究计划倒计时"><div class="plan-banner-text"><span class="small-label">${icon('spark')} 你的三周研究计划</span><h2>${c.remaining>=0?'为下一次进度发表，':'整理已有发现，'}<br>积累一点确定的进展。</h2><button class="text-button" data-action="nav" data-route="progress">查看研究进度 ${icon('arrow')}</button></div><div class="countdown-art"><div class="art-orbit"></div><span class="art-star star-one">✳</span><span class="art-star star-two">✧</span><div class="day-number">${c.remaining>=0?Math.max(0,c.remaining):Math.abs(c.remaining)}<small>${c.remaining>=0?'天后 · 进度发表':'天 · 到期后'}</small></div><div class="art-steps"><i></i><i></i><i></i><i></i></div></div><div class="plan-date">${dateLabel(state.settings.targetDate)} ${icon('arrow')}</div></section>
      <div class="stats-strip"><div>${icon('check')}<p><strong>${stats.tasks.length}</strong><span>今日完成</span></p></div><div>${icon('clock')}<p><strong>${stats.minutes}<small> min</small></strong><span>今日专注</span></p></div><div>${icon('book')}<p><strong>${stats.logs.length}</strong><span>今日记录</span></p></div></div>
      <section class="task-section"><div class="section-heading"><h2>我的行动清单 <span>${open.length} 项待办</span></h2><span class="subtle">一步一步来</span></div>
        <div class="task-tabs" role="tablist" aria-label="任务分类">${[['today','今日'],['open','未完成'],['done','已完成']].map(([key,label])=>`<button role="tab" aria-selected="${tab===key}" class="${tab===key?'selected':''}" data-action="tab" data-tab="${key}">${label}<span>${visibleTasks(state,key).length}</span></button>`).join('')}</div>
        <p class="filter-note">${tab==='today'?'今日显示：到期、已过期，以及尚未设截止日期的任务。':tab==='done'?'每一个完成，都值得被看见。':'按优先级和截止日期排列，挑一件开始。'}</p>
        <div class="task-list">${items.length?items.map(t=>taskCard(t,today)).join(''):emptyTasks(tab)}</div>
        <button class="quick-add" data-action="add-task">${icon('plus')} 写下可以开始的一小步</button>
      </section>
    </div><aside class="right-column">${focusCard(next)}
      <section class="card note-card"><span class="small-label">${icon('book')} 留下今天的发现</span><h3>结果、报错、卡住的地方，<br>都是研究的一部分。</h3><p>不用写成报告。几句话，让明天的自己接着往下走。</p><button class="text-button" data-action="add-log">写一条研究日志 ${icon('arrow')}</button></section>
      <div class="gentle-note">${icon('leaf')}<p>有卡点时，把问题写具体，<br>带着它去找老师聊一聊。</p></div>
    </aside></div>`;
}
function taskCard(t,today) {
  const overdue=t.due && t.due<today && !t.completedAt;
  return `<article class="task-card ${t.completedAt?'completed':''}"><button class="check-button ${t.completedAt?'checked':''}" data-action="toggle-task" data-id="${esc(t.id)}" aria-label="${t.completedAt?'重新打开':'完成'}任务：${esc(t.title)}">${t.completedAt?icon('check'):''}</button><div class="task-body"><button class="task-title" data-action="edit-task" data-id="${esc(t.id)}">${esc(t.title)}</button>${t.note?`<p>${esc(t.note)}</p>`:''}<div class="task-meta"><span class="priority ${t.priority}"><i></i>${priority[t.priority]}</span>${t.due?`<span class="${overdue?'overdue':''}">${icon('calendar')}${t.due===today?'今天截止':dateLabel(t.due)}${overdue?' · 已过期':''}</span>`:'<span>未设截止日期</span>'}</div></div><div class="task-actions">${!t.completedAt?`<button class="icon-button" data-action="focus-task" data-id="${esc(t.id)}" aria-label="专注于：${esc(t.title)}">${icon('play')}</button>`:''}<button class="icon-button" data-action="edit-task" data-id="${esc(t.id)}" aria-label="编辑任务：${esc(t.title)}">${icon('edit')}</button><button class="icon-button" data-action="delete-task" data-id="${esc(t.id)}" aria-label="删除任务：${esc(t.title)}">${icon('trash')}</button></div></article>`;
}
function emptyTasks(kind) { return `<div class="empty-state"><span class="empty-icon">${icon(kind==='done'?'check':'step')}</span><h3>${kind==='done'?'完成的每一步，会留在这里':kind==='today'?'今天，从一小步开始':'把脑海里的待办，放到这里'}</h3><p>${kind==='today'?'比如：跑通一次基线仿真，或整理一个具体问题。':kind==='done'?'不用急着证明什么，先完成一件具体的小事。':'写清动作、设好优先级，就可以开始了。'}</p></div>`; }
function focusCard(next) {
  const tasks=state.tasks.filter(t=>!t.completedAt);
  if(!tasks.some(t=>t.id===selectedTask)) selectedTask=next?.id||'';
  return `<section class="card focus-card"><div class="section-heading"><span class="small-label">${icon('clock')} 一次，只专注一件事</span><span class="focus-dot"></span></div><div class="timer-orbit"><svg viewBox="0 0 200 200" aria-hidden="true"><circle class="timer-track" cx="100" cy="100" r="88"/><circle id="timer-progress" cx="100" cy="100" r="88"/></svg><div><span id="timer-display" class="timer-display">25:00</span><span id="timer-label" class="timer-label">留给眼前的一小步</span></div></div>
      <label class="focus-select-label" for="focus-task">这次打算做什么？</label>${state.timer?`<p class="current-focus">${esc(state.timer.title)}</p>`:`<select id="focus-task"><option value="">自由专注 · 先开始也可以</option>${tasks.map(t=>`<option value="${esc(t.id)}" ${selectedTask===t.id?'selected':''}>${esc(t.title)}</option>`).join('')}</select>`}
      <div class="focus-buttons"><button class="button primary" data-action="focus-toggle">${icon(state.timer?.endAt?'pause':'play')} ${state.timer?.endAt?'暂停一下':state.timer?'继续专注':'开始 25 分钟'}</button>${state.timer?`<button class="icon-button reset-button" data-action="focus-reset" aria-label="结束本次计时">${icon('reset')}</button>`:''}</div>
      <p class="focus-footnote">${native?'切到后台，计时也会继续。':'切换页面后继续计时；关闭浏览器后无准点提醒。'}</p></section>`;
}
function logsPage() {
  const logs=[...state.logs].filter(l=>logFilter!=='blocked'||l.blocker||l.error).sort((a,b)=>b.date.localeCompare(a.date)||b.createdAt.localeCompare(a.createdAt));
  return `<div class="page-heading"><div><p class="eyebrow">RESEARCH JOURNAL <span>· 留下思考的痕迹</span></p><h1>今天发现了什么<span class="orange">？</span></h1><p class="subtitle">跑出来的结果，没跑通的报错，都值得记录。</p></div><button class="button primary heading-button" data-action="add-log">${icon('plus')} 写研究日志</button></div><div class="journal-toolbar"><div class="task-tabs" role="tablist" aria-label="日志筛选"><button role="tab" aria-selected="${logFilter==='all'}" class="${logFilter==='all'?'selected':''}" data-action="log-filter" data-filter="all">全部记录 <span>${state.logs.length}</span></button><button role="tab" aria-selected="${logFilter==='blocked'}" class="${logFilter==='blocked'?'selected':''}" data-action="log-filter" data-filter="blocked">报错与卡点 <span>${state.logs.filter(l=>l.error||l.blocker).length}</span></button></div><span class="subtle">保留过程，也保留不确定性。</span></div><div class="journal-grid">${logs.length?logs.map(l=>`<article class="card journal-card"><div class="section-heading"><span class="journal-date">${icon('calendar')}${esc(l.date)}</span><div><button class="icon-button" data-action="edit-log" data-id="${esc(l.id)}" aria-label="编辑日志：${esc(l.title)}">${icon('edit')}</button><button class="icon-button" data-action="delete-log" data-id="${esc(l.id)}" aria-label="删除日志：${esc(l.title)}">${icon('trash')}</button></div></div><h2>${esc(l.title)}</h2>${[['result','仿真 / 结果'],['error','报错'],['blocker','卡点'],['next','下一步']].filter(([key])=>l[key]).map(([key,label])=>`<div class="log-field ${key}"><h3>${label}</h3><p>${esc(l[key])}</p></div>`).join('')}</article>`).join(''):`<div class="card journal-empty">${icon('book')}<h2>${logFilter==='blocked'?'这里暂时没有报错或卡点':'第一条记录，不需要很完美'}</h2><p>${logFilter==='blocked'?'遇到问题时，记下复现方式、报错原文和尝试过的办法。':'今天做了什么？结果怎样？明天从哪里接着做？'}</p><button class="button secondary" data-action="add-log">写下今天的发现 ${icon('arrow')}</button></div>`}</div>`;
}
function progressPage(c) {
  const all=weeks(state), today=localDate();
  return `<div class="page-heading"><div><p class="eyebrow">ONE STEP AT A TIME <span>· 看见积累</span></p><h1>把三周，走成具体的进展<span class="orange">。</span></h1><p class="subtitle">${esc(state.settings.project)} · ${esc(state.settings.startDate)} — ${esc(state.settings.targetDate)}</p></div><button class="button secondary heading-button" data-action="edit-plan">${icon('edit')} 调整计划</button></div><section class="card progress-hero"><div><span class="small-label">距离进度发表</span><h2>${countdownText(c)}</h2><p>不需要等一切准备好，先积累可以展示的证据。</p></div><div class="progress-overview"><div class="section-heading"><span>时间进度</span><strong>${Math.round(c.progress)}%</strong></div><div class="progress-bar"><i style="width:${c.progress}%"></i></div><p>这是时间进度；研究成果由下面的真实记录呈现。</p></div></section><div class="section-heading week-title"><h2>每周，整理一次</h2><span class="subtle">摘要来自你的任务、专注与日志</span></div><div class="week-grid">${all.map((w,i)=>`<section class="card week-card ${w.start<=today&&w.end>=today?'current-week':''}"><div class="section-heading"><span class="week-number">0${i+1}</span><span class="week-state">${w.start>today?'即将开始':w.end<today?'已走过':'正在这一周'}</span></div><h2>第 ${i+1} 周<span>${dateLabel(w.start)} — ${dateLabel(w.end)}</span></h2><div class="week-metrics"><div><strong>${w.tasks.length}</strong><span>完成任务</span></div><div><strong>${w.minutes}</strong><span>专注分钟</span></div><div><strong>${w.logs.length}</strong><span>研究日志</span></div></div><p class="week-excerpt">${esc(w.logs.find(l=>l.result)?.result || w.logs.find(l=>l.blocker)?.blocker || (w.start>today?'留一点空间，给接下来要发生的发现。':'完成一次行动、写下一条记录后，积累会出现在这里。'))}</p><button class="text-button" data-action="summary" data-week="${i}">查看本周摘要 ${icon('arrow')}</button></section>`).join('')}</div><section class="progress-note">${icon('leaf')}<div><h3>汇报时，也带上还没解决的问题。</h3><p>有结果就展示结果，有卡点就展示尝试、证据与下一步。记录会帮你把它们讲清楚。</p></div></section>`;
}
function settingsPage() {
  const s=state.settings;
  return `<div class="page-heading"><div><p class="eyebrow">MAKE ROOM FOR PROGRESS <span>· 按你的节奏</span></p><h1>给行动，一点温和的支持<span class="orange">。</span></h1><p class="subtitle">提醒你回来，也让你的研究记录安心留下。</p></div></div><div class="settings-grid"><section class="card settings-card"><div class="settings-title">${icon('bell')}<h2>每日两次，轻轻提醒</h2></div><p>${native?'使用 Android 系统本地通知，离线也可提醒。时间跟随设备时区。':'网页版仅在页面打开且可见时检查提醒；关闭页面后不能准点通知。需要后台提醒时，请使用 Android 安装版。'}</p><form id="reminder-form"><div class="time-fields"><label>开始今天<input name="morning" type="time" value="${esc(s.times[0])}" required></label><label>回顾今天<input name="evening" type="time" value="${esc(s.times[1])}" required></label></div><label class="switch-row"><span>${native?'开启每日本地通知':'开启页面内每日提醒'}<small>${s.reminders?'已开启':'由你决定什么时候开启'}</small></span><input type="checkbox" name="enabled" ${s.reminders?'checked':''} role="switch"></label><button class="button primary" type="submit">保存提醒设置</button></form><div class="notification-state">${icon('bell')}<span>${native?(notificationsGranted?(s.reminders?'通知已授权 · '+(exact?'精确提醒已允许':'系统可能延迟，支持开启精确提醒'):'通知已授权，定时提醒未开启'):'系统通知未授权，请保存设置时允许通知'):'页面内提醒 · 不提供浏览器后台定时通知'}</span></div><div class="button-row"><button class="text-button" data-action="test-notification">发送测试通知 ${icon('arrow')}</button>${native?'<button class="text-button" data-action="exact">精确提醒设置</button>':''}</div><blockquote>“选一个可以动手的小任务。先做 25 分钟，也是一份进展。”</blockquote></section>
      <section class="card settings-card"><div class="settings-title">${icon('shield')}<h2>本地数据与备份</h2></div><p>任务、日志和专注记录保存在此设备，不上传服务器。浏览器版和 Android 版的数据各自独立，可用备份迁移。</p><div class="data-counts"><span><strong>${state.tasks.length}</strong> 项任务</span><span><strong>${state.logs.length}</strong> 篇日志</span><span><strong>${state.sessions.length}</strong> 次专注</span></div><div class="backup-buttons"><button class="button primary" data-action="export">${icon('download')} 导出备份</button><button class="button secondary" data-action="import">${icon('upload')} 恢复备份</button><input type="file" accept=".json,application/json" id="backup-file" hidden></div><p class="backup-date">${state.lastBackupAt?'上次发起备份：'+new Date(state.lastBackupAt).toLocaleString('zh-CN'):'还没有导出备份，建议每周保存一次。'}</p><button class="text-button" data-action="undo-restore">撤销上一次恢复 ${icon('arrow')}</button><div class="data-warning">卸载 App、清除网站数据或更换网址可能丢失本地记录。请把备份保存在设备外；备份包含研究原文，请妥善保管。</div><button class="text-button persist-button" data-action="persist">${icon('shield')}${persistent?'已获得持久存储保护':'申请持久存储保护'}</button><small class="subtle block">持久存储可减少自动清理，不能代替备份。</small></section>
      <section class="card settings-card compact"><div class="settings-title">${icon('calendar')}<h2>研究计划</h2></div><strong class="project-name">${esc(s.project)}</strong><p>${esc(s.startDate)} → ${esc(s.targetDate)}</p><button class="text-button" data-action="edit-plan">调整计划名称与日期 ${icon('arrow')}</button></section>
      <section class="card settings-card compact"><div class="settings-title">${icon('step')}<h2>随手打开，随时开始</h2></div><p>${native?'一步 Android · v1.0.0':'在 Android Chrome 菜单中选择“添加到主屏幕”或“安装应用”，即可像 App 一样打开。'}</p>${!native?`<button class="button secondary" data-action="install">${icon('plus')} 安装到主屏幕</button>`:''}<small class="subtle block">${shellCached?'离线资源已缓存，下次断网也能打开。':native?'安装包已包含全部离线页面。':'首次联网打开后自动缓存离线页面。'}</small></section></div>`;
}

let returnFocus;
function showModal(content,wide=false) {
  returnFocus=document.activeElement;
  modal.className=wide?'wide':'';
  modal.innerHTML=content;
  if(!modal.open) modal.showModal();
  modal.setAttribute('aria-labelledby','modal-title');
  queueMicrotask(()=>(modal.querySelector('[autofocus]')||modal.querySelector('input,textarea,button'))?.focus());
}
function closeModal() { modal.close(); restoreCandidate=null; if(returnFocus?.isConnected) returnFocus.focus(); }
function modalHead(kicker,title) { return `<div class="modal-heading"><div><span class="eyebrow">${kicker}</span><h2 id="modal-title">${title}</h2></div><button type="button" class="icon-button" data-action="close-modal" aria-label="关闭弹窗">${icon('close')}</button></div>`; }
const modalFoot=(label='保存')=>`<div class="modal-footer"><button class="button secondary" type="button" data-action="close-modal">取消</button><button class="button primary" type="submit">${label} ${icon('arrow')}</button></div>`;
function taskModal(id) {
  const t=state.tasks.find(t=>t.id===id);
  showModal(`${modalHead('A SMALL STEP',t?'编辑这一小步':'写下你的下一步')}<form id="task-form" data-id="${esc(id||'')}"><label>具体要做什么？<input autofocus name="title" maxlength="200" required placeholder="例如：跑通一组基线仿真" value="${esc(t?.title)}"></label><label>补充说明 <span class="optional">选填</span><textarea name="note" maxlength="2000" rows="3" placeholder="第一步怎么做？完成的标准是什么？">${esc(t?.note)}</textarea></label><fieldset><legend>优先级</legend><div class="priority-options">${Object.entries(priority).map(([value,label])=>`<label><input type="radio" name="priority" value="${value}" ${(t?.priority||'medium')===value?'checked':''}><span class="priority ${value}"><i></i>${label}</span></label>`).join('')}</div></fieldset><label>截止日期 <span class="optional">选填</span><input type="date" name="due" value="${esc(t ? (t.due||'') : localDate())}"></label><p class="form-tip">把任务写小一点，让自己真的能开始。</p>${modalFoot(t?'保存修改':'添加这一步')}</form>`);
}
function logModal(id) {
  const l=state.logs.find(l=>l.id===id);
  showModal(`${modalHead('LEAVE A TRACE',l?'编辑研究日志':'留下今天的发现')}<form id="log-form" data-id="${esc(id||'')}"><div class="two-fields"><label>记录日期<input name="date" type="date" required value="${esc(l?.date||localDate())}"></label><label>一句话标题<input autofocus name="title" maxlength="200" required value="${esc(l?.title)}" placeholder="例如：基线仿真第一次跑通"></label></div>${[['result','仿真 / 结果','用了什么参数？得到什么现象？也可以写负面结果。'],['error','报错','保留报错原文、复现条件和尝试过的修复。'],['blocker','卡点','哪里还不确定？需要向老师请教什么？'],['next','下一步','下次打开时，可以直接动手的第一件事。']].map(([key,label,placeholder])=>`<label>${label} <span class="optional">选填</span><textarea name="${key}" maxlength="20000" rows="${key==='result'?3:2}" placeholder="${placeholder}">${esc(l?.[key])}</textarea></label>`).join('')}<p class="form-tip">一条具体的观察，也是一条有价值的研究记录。</p>${modalFoot('保存研究日志')}</form>`,true);
}
function planModal() {
  const s=state.settings;
  showModal(`${modalHead('THREE WEEKS, ONE STEP', '给研究一个时间坐标')}<form id="plan-form"><label>计划名称<input name="project" maxlength="100" required value="${esc(s.project)}"></label><div class="two-fields"><label>开始日期<input name="start" type="date" required value="${esc(s.startDate)}"></label><label>进度发表日期<input name="target" type="date" required value="${esc(s.targetDate)}"></label></div><p class="form-tip">默认从首次打开起 21 天。摘要按开始日期起的三周分组，调整日期不会删除记录。</p>${modalFoot('保存计划')}</form>`);
}
function confirmModal(title,text,callback,label='确认删除') {
  showModal(`${modalHead('TAKE A MOMENT',title)}<p class="confirm-text">${esc(text)}</p><div class="modal-footer"><button class="button secondary" data-action="close-modal">取消</button><button class="button ${label==='确认删除'?'danger':'primary'}" id="confirm-action">${label}</button></div>`);
  document.querySelector('#confirm-action').onclick=async event=>{event.currentTarget.disabled=true; try{await callback();closeModal();}catch(e){report(e);document.querySelector('#confirm-action').disabled=false;}};
}
async function updateTimerState(change) { await mutate(change); try{await focusNotification(state.timer);}catch{toast('计时已保存，但系统结束提醒未安排。请检查通知权限。');} }
async function toggleFocus() {
  if(state.timer) {
    await updateTimerState(s=>{if(s.timer.endAt){s.timer.remaining=remainingMs(s.timer);s.timer.endAt=null;}else s.timer.endAt=Date.now()+s.timer.remaining;});
  } else {
    const task=state.tasks.find(t=>t.id===selectedTask);
    await updateTimerState(s=>{s.timer={id:uid(),taskId:task?.id||null,title:task?.title||'自由专注',remaining:FOCUS_MS,endAt:Date.now()+FOCUS_MS};});
  }
}
function updateClock() {
  const ms=remainingMs(state?.timer), seconds=Math.ceil(ms/1000);
  const display=document.querySelector('#timer-display');
  if(display) display.textContent=`${String(Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
  const label=document.querySelector('#timer-label'); if(label) label.textContent=state.timer?(state.timer.endAt?'只需照顾眼前这一件事':'暂停一下，也可以'):'留给眼前的一小步';
  const ring=document.querySelector('#timer-progress'); if(ring) ring.style.strokeDashoffset=String(553*(1-ms/FOCUS_MS));
  document.title=state.timer?`${display?.textContent||Math.ceil(ms/60000)+' min'} · 一步专注中`:'一步 · 让研究向前一点';
}
async function tick() {
  if(!ready || ticking) return;
  updateClock();
  if(state.timer?.endAt && remainingMs(state.timer)===0) {
    ticking=true;
    try { await mutate(s=>finishTimer(s)); toast('25 分钟，完成了。休息一下，记下这次发现。',()=>logModal(),'记一条日志'); if(!native && document.visibilityState==='visible' && await permission()) await notifyNow(0,{title:'一步 · 25 分钟，完成了',body:'休息一下，记下这次发现。每一步，都算数。'}); }
    catch(e){report(e);} finally{ticking=false;}
  }
  if(!native && state.settings.reminders && document.visibilityState==='visible') {
    const now=new Date(), time=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    state.settings.times.forEach((t,i)=>{ const key=`${localDate()}-${i}`; if(t===time && !reminded.has(key)) { reminded.add(key); toast(i===0?'今天从一件事开始：选一个可以动手的小任务。':'给今天留下一点记录：结果、报错或卡点都可以。',()=>go(i===0?'tasks':'logs'),'打开'); if(notificationsGranted) notifyNow(i).catch(()=>{}); } });
  }
  if(daySeen!==localDate()){daySeen=localDate();render();}
}
let daySeen=localDate(); const reminded=new Set();

document.addEventListener('change',event=>{if(event.target.id==='focus-task')selectedTask=event.target.value;});
document.addEventListener('click',async event=>{
  const button=event.target.closest('[data-action]'); if(!button || !ready) return;
  const action=button.dataset.action, id=button.dataset.id;
  event.preventDefault();
  try {
    if(action==='nav')go(button.dataset.route);
    else if(action==='home')go('tasks');
    else if(action==='tab'){tab=button.dataset.tab;render();}
    else if(action==='log-filter'){logFilter=button.dataset.filter;render();}
    else if(action==='add-task')taskModal();
    else if(action==='edit-task')taskModal(id);
    else if(action==='add-log')logModal();
    else if(action==='edit-log')logModal(id);
    else if(action==='close-modal')closeModal();
    else if(action==='toggle-task') {
      const before=state.tasks.find(t=>t.id===id)?.completedAt;
      await mutate(s=>{const t=s.tasks.find(t=>t.id===id);t.completedAt=t.completedAt?null:new Date().toISOString();});
      toast(before?'这一步已重新打开。':'又完成了一步。',()=>mutate(s=>{const t=s.tasks.find(t=>t.id===id);if(t)t.completedAt=before;}));
    } else if(action==='delete-task'||action==='delete-log') {
      const key=action==='delete-task'?'tasks':'logs', item=state[key].find(i=>i.id===id);
      confirmModal(key==='tasks'?'删除这项任务？':'删除这篇日志？',`“${item.title}”将被删除。删除后可通过短暂出现的撤销按钮找回。`,async()=>{await mutate(s=>{s[key]=s[key].filter(i=>i.id!==id);});toast('已删除。',()=>mutate(s=>{if(!s[key].some(i=>i.id===id))s[key].push(item);}));});
    } else if(action==='focus-toggle')await toggleFocus();
    else if(action==='focus-task') {
      if(state.timer) {go('tasks');document.querySelector('.focus-card')?.scrollIntoView({behavior:'smooth',block:'center'});toast('当前已有一次专注，可先暂停或结束。');}
      else {selectedTask=id;go('tasks');await toggleFocus();document.querySelector('.focus-card')?.scrollIntoView({behavior:'smooth',block:'center'});}
    } else if(action==='focus-reset')confirmModal('结束这次专注？','未完成的计时不会计入专注记录。已经完成的记录会保留。',()=>updateTimerState(s=>{s.timer=null;}),'结束本次');
    else if(action==='edit-plan')planModal();
    else if(action==='summary') {
      const w=weeks(state)[Number(button.dataset.week)], text=summaryText(state,w);
      showModal(`${modalHead('WEEKLY REFLECTION','第 '+(Number(button.dataset.week)+1)+' 周 · 研究摘要')}<pre class="summary-content">${esc(text)}</pre><div class="modal-footer"><button class="button secondary" id="summary-copy">${icon('copy')} 复制摘要</button><button class="button primary" id="summary-save">${icon('download')} 导出文本</button></div>`,true);
      document.querySelector('#summary-copy').onclick=()=>navigator.clipboard.writeText(text).then(()=>toast('摘要已复制。')).catch(()=>toast('无法使用剪贴板，请导出文本。'));
      document.querySelector('#summary-save').onclick=()=>exportFile(`一步-周摘要-${w.start}.md`,text,'text/markdown').catch(report);
    } else if(action==='test-notification') {notificationsGranted=await permission(true);if(!notificationsGranted)throw new Error('通知未获授权。可在系统或浏览器设置中允许通知。');await notifyNow();toast('已发送测试通知，请查看系统通知栏。');render();}
    else if(action==='exact'){await requestExact();exact=await exactStatus();render();}
    else if(action==='export') {
      await exportFile(`一步-备份-${localDate()}.json`,exportBackup(state));
      await mutate(s=>{s.lastBackupAt=new Date().toISOString();}); toast(native?'已打开分享窗口，请确认备份已保存到你选择的位置。':'已发起下载，请确认备份文件已保存。');
    } else if(action==='import') document.querySelector('#backup-file').click();
    else if(action==='undo-restore') {
      const previous=await get('beforeRestore'); if(!previous)throw new Error('还没有可撤销的恢复记录。');
      confirmModal('回到上一次恢复之前？','这会替换目前的任务与日志。当前数据也会保留，可再次切换回来。',async()=>{await replaceState(previous);toast('已找回恢复前的数据。');},'恢复之前的数据');
    } else if(action==='persist') {persistent=!!(await navigator.storage?.persist?.());toast(persistent?'已获得持久存储保护。仍建议定期备份。':'此环境未授予持久存储，请定期导出备份。');render();}
    else if(action==='install') {
      if(installPrompt){await installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;}
      else toast('请在 Android Chrome 右上角菜单中选择“添加到主屏幕”或“安装应用”。');
    } else if(action==='update'){await queue;waitingWorker?.postMessage({type:'SKIP_WAITING'});}
  } catch(e){report(e);}
});

document.addEventListener('submit',async event=>{
  const form=event.target;
  if(!['task-form','log-form','plan-form','reminder-form'].includes(form.id))return;
  event.preventDefault(); const data=new FormData(form), submit=form.querySelector('[type="submit"]'); submit.disabled=true;
  const value=key=>String(data.get(key)||'').trim();
  try {
    if(form.id==='task-form') {
      if(!value('title')) throw new Error('请写下一个具体的任务。');
      await mutate(s=>{
        const existing=s.tasks.find(t=>t.id===form.dataset.id);
        const fields={title:value('title'),note:value('note'),due:value('due')||null,priority:value('priority')};
        if(existing)Object.assign(existing,fields);else s.tasks.push({id:uid(),...fields,createdAt:new Date().toISOString(),completedAt:null});
      }); closeModal();toast('这一步已保存。');
    } else if(form.id==='log-form') {
      if(!value('title'))throw new Error('请给这条记录写一个标题。');
      await mutate(s=>{
        const existing=s.logs.find(l=>l.id===form.dataset.id);
        const fields=Object.fromEntries(['date','title','result','error','blocker','next'].map(k=>[k,value(k)]));
        if(existing)Object.assign(existing,fields);else s.logs.push({id:uid(),...fields,createdAt:new Date().toISOString()});
      }); closeModal();toast('今天的发现，留下来了。');
    } else if(form.id==='plan-form') {
      if(value('target')<value('start'))throw new Error('发表日期需要在开始日期当天或之后。');
      if(!value('project'))throw new Error('请写下计划名称。');
      await mutate(s=>{Object.assign(s.settings,{project:value('project'),startDate:value('start'),targetDate:value('target')});}); closeModal();toast('研究计划已更新。');
    } else {
      const enabled=data.get('enabled')==='on', settings={...state.settings,times:[value('morning'),value('evening')],reminders:enabled};
      if(settings.times[0]===settings.times[1])throw new Error('请为两次提醒选择不同的时间。');
      if(enabled && native) {notificationsGranted=await permission(true);if(!notificationsGranted)throw new Error('系统通知未获授权，提醒设置没有更改。请在系统设置中允许通知。');}
      await syncReminders(settings);
      try {await mutate(s=>{s.settings=settings;});}catch(e){await syncReminders(state.settings).catch(()=>{});throw e;}
      toast(enabled?(native?'每天两次本地提醒已安排。':'页面内提醒已开启，关闭页面后不提供定时提醒。'):'提醒已关闭。');
    }
  } catch(e){report(e);} finally{if(submit.isConnected)submit.disabled=false;}
});
async function replaceState(replacement) {
  const run=queue.then(async()=>{
    const previous=structuredClone(state), next=structuredClone(replacement);
    next.timer=null; next.settings.reminders=false;
    await save(next,previous);state=next;render();
    try {await syncReminders(state.settings);await focusNotification(null);}catch{toast('数据已恢复，但旧提醒取消失败。请在系统通知设置中检查。');}
  });
  queue=run.catch(()=>{});
  return run;
}
document.addEventListener('change',async event=>{
  if(event.target.id!=='backup-file')return;
  const file=event.target.files?.[0]; if(!file)return;
  try {
    if(file.size>10*1024*1024)throw new Error('备份文件超过 10 MB。');
    restoreCandidate=parseBackup(await file.text());
    showModal(`${modalHead('RESTORE WITH CARE','恢复这份研究记录？')}<p class="confirm-text">备份包含 <strong>${restoreCandidate.tasks.length}</strong> 项任务、<strong>${restoreCandidate.logs.length}</strong> 篇日志、<strong>${restoreCandidate.sessions.length}</strong> 次专注。<br><br>将替换当前数据，恢复前的数据会自动保留，可在设置中撤销。通知需在本设备重新开启，计时不会迁移。</p><div class="modal-footer"><button class="button secondary" data-action="close-modal">取消</button><button class="button primary" id="restore-confirm">确认恢复</button></div>`);
    document.querySelector('#restore-confirm').onclick=async e=>{e.currentTarget.disabled=true;try{await replaceState(restoreCandidate);closeModal();toast('备份已恢复，可以接着往前走了。');}catch(error){report(error);document.querySelector('#restore-confirm').disabled=false;}};
  } catch(e){report(e);} finally{event.target.value='';}
});
modal.addEventListener('cancel',()=>{restoreCandidate=null;});
window.addEventListener('online',()=>render());window.addEventListener('offline',()=>render());
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')void resume();});
async function resume() {if(!ready)return;await tick();try{notificationsGranted=await permission();exact=await exactStatus();await syncReminders(state.settings);await focusNotification(state.timer);if(route==='settings')render();}catch(e){report(e);}}
async function start() {
  try {
    if(!await acquireLock())throw new Error('一步已在另一个窗口打开。请关闭另一个窗口后刷新，避免覆盖记录。');
    state=await openStore();await save(state);
    notificationsGranted=await permission();exact=await exactStatus();persistent=!!(await navigator.storage?.persisted?.());
    ready=true;render();await tick();
    setInterval(()=>void tick(),500);
    await initNative(()=>void resume(),go);
    await syncReminders(state.settings);await focusNotification(state.timer);
  } catch(error) {
    if(!ready)app.innerHTML=`<main class="startup-error">${icon('shield')}<h1>先保护好你的记录</h1><p>${esc(error.message)}</p><p>请使用普通浏览模式，允许本地存储，然后刷新页面。现有记录不会被重置。</p><button class="button primary" onclick="location.reload()">重新打开</button></main>`;
    else report(error);
  } finally {setTimeout(()=>document.querySelector('#splash')?.remove(),1600);}
  if(!native && 'serviceWorker' in navigator && import.meta.env.PROD) {
    try {
      const reg=await navigator.serviceWorker.register('/sw.js');
      if(reg.waiting){waitingWorker=reg.waiting;render();}
      reg.addEventListener('updatefound',()=>{const worker=reg.installing;worker?.addEventListener('statechange',()=>{if(worker.state==='installed' && navigator.serviceWorker.controller){waitingWorker=worker;render();}});});
      navigator.serviceWorker.ready.then(()=>{shellCached=true;if(route==='settings')render();});
      navigator.serviceWorker.addEventListener('controllerchange',()=>{if(waitingWorker)location.reload();});
    } catch {toast('离线页面暂未缓存。请保持联网后重试。');}
  }
}
void start();
