import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { App } from '@capacitor/app';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
import { SplashScreen } from '@capacitor/splash-screen';
export const native=Capacitor.isNativePlatform();
const channelId='yibu-gentle';
const channel=()=>LocalNotifications.createChannel({id:channelId,name:'一步 · 温和提醒',description:'每天两次研究行动提醒与专注结束提醒',importance:4,visibility:1});
const messages=[{title:'一步 · 今天从一件事开始',body:'选一个可以动手的小任务。先做 25 分钟，也是一份进展。'},{title:'一步 · 给今天留下一点记录',body:'记下结果、报错或卡点，再写下明天的第一步。'}];
export async function permission(request=false) {
  if(native) return (await (request?LocalNotifications.requestPermissions():LocalNotifications.checkPermissions())).display==='granted';
  if(!('Notification' in window)) return false;
  return (request?await Notification.requestPermission():Notification.permission)==='granted';
}
export async function syncReminders(settings) {
  if(!native) return;
  await LocalNotifications.cancel({notifications:[{id:101},{id:102}]});
  if(!settings.reminders || !await permission()) return;
  await channel();
  const precise=await exactStatus();
  await LocalNotifications.schedule({ notifications:settings.times.map((time,i)=>{ const [hour,minute]=time.split(':').map(Number); return {id:101+i,...messages[i],channelId,isExactNotification:precise,schedule:{on:{hour,minute},allowWhileIdle:true},extra:{route:i===0?'tasks':'logs'}}; }) });
}
export async function exactStatus() { if(!native) return false; try{return (await LocalNotifications.checkExactNotificationSetting()).exact_alarm==='granted';}catch{return false;} }
export async function requestExact() { if(native) await LocalNotifications.changeExactNotificationSetting(); }
export async function focusNotification(timer) {
  if(!native) return;
  await LocalNotifications.cancel({notifications:[{id:103}]});
  if(!timer?.endAt || timer.endAt<=Date.now() || !await permission()) return;
  await channel();
  await LocalNotifications.schedule({notifications:[{id:103,title:'一步 · 25 分钟，完成了',body:'休息一下，再记下这次发现。每一步，都算数。',channelId,isExactNotification:await exactStatus(),schedule:{at:new Date(timer.endAt),allowWhileIdle:true},extra:{route:'logs'}}]});
}
export async function notifyNow(index=0, custom) {
  const message=custom || messages[index];
  if(native) {
    if(!await permission()) throw new Error('请先允许通知，再发送测试提醒。');
    await channel();
    await LocalNotifications.schedule({notifications:[{id:104,...message,channelId,isExactNotification:false}]});
  } else {
    if(!await permission()) throw new Error('请先允许浏览器通知。');
    const reg=await navigator.serviceWorker?.getRegistration();
    if(reg) await reg.showNotification(message.title,{body:message.body,icon:'/icons/icon-192.png',tag:'yibu-reminder'});
    else new Notification(message.title,{body:message.body});
  }
}
export async function exportFile(name,text,type='application/json') {
  if(native) {
    const file=await Filesystem.writeFile({path:name,data:text,directory:Directory.Cache,encoding:Encoding.UTF8});
    await Share.share({title:name,url:file.uri,dialogTitle:'保存或分享备份'});
  } else {
    const url=URL.createObjectURL(new Blob([text],{type}));
    const a=document.createElement('a'); a.href=url; a.download=name; a.click(); setTimeout(()=>URL.revokeObjectURL(url),30000);
  }
}
export async function initNative(onResume,onRoute) {
  if(!native) return;
  await SplashScreen.hide();
  await App.addListener('appStateChange',({isActive})=>{if(isActive) onResume();});
  await LocalNotifications.addListener('localNotificationActionPerformed',event=>onRoute(event.notification.extra?.route || 'tasks'));
}
