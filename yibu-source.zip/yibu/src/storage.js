import { initialState, validateState } from './core.js';
let db;
export async function openStore() {
  db=await new Promise((resolve,reject)=>{
    const request=indexedDB.open('yibu-research',1);
    request.onupgradeneeded=()=>request.result.createObjectStore('records');
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error);
    request.onblocked=()=>reject(new Error('请关闭其他「一步」窗口后重试。'));
  });
  db.onversionchange=()=>db.close();
  const state=await get('state');
  return state ? validateState(state) : initialState();
}
export function get(key) { return new Promise((resolve,reject)=>{ const tx=db.transaction('records','readonly'); const r=tx.objectStore('records').get(key); r.onsuccess=()=>resolve(r.result); r.onerror=()=>reject(r.error); }); }
export function save(state, recovery) {
  const safe=validateState(state);
  return new Promise((resolve,reject)=>{
    const tx=db.transaction('records','readwrite'); const store=tx.objectStore('records');
    if(recovery) store.put(validateState(recovery),'beforeRestore');
    store.put(safe,'state');
    tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error); tx.onabort=()=>reject(tx.error || new Error('保存被中断'));
  });
}
export async function acquireLock() {
  if(!navigator.locks) return true;
  return new Promise((resolve)=>{
    navigator.locks.request('yibu-writer',{ifAvailable:true},lock=>{
      resolve(!!lock);
      if(lock) return new Promise(()=>{});
    });
  });
}
