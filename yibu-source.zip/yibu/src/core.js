export const APP_ID = 'app.yibu.research';
export const SCHEMA = 1;
export const FOCUS_MS = 25 * 60 * 1000;
export const uid = () => crypto.randomUUID();
export const localDate = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
export function dayIndex(date) { const [y,m,d] = date.split('-').map(Number); return Date.UTC(y,m-1,d) / 86400000; }
export function addDays(date, days) { const d = new Date(`${date}T12:00:00`); d.setDate(d.getDate()+days); return localDate(d); }
export const dateLabel = date => new Date(`${date}T12:00:00`).toLocaleDateString('zh-CN', { month:'long', day:'numeric' });
export function initialState(today = localDate()) {
  return { schema:SCHEMA, tasks:[], logs:[], sessions:[], settings:{ startDate:today, targetDate:addDays(today,21), project:'三周研究计划', reminders:false, times:['09:00','20:00'] }, timer:null, lastBackupAt:null };
}
export function visibleTasks(state, tab, today = localDate()) {
  return state.tasks.filter(t => tab === 'done' ? t.completedAt : !t.completedAt && (tab !== 'today' || !t.due || t.due <= today))
    .sort((a,b) => tab === 'done' ? b.completedAt.localeCompare(a.completedAt) : ({high:0,medium:1,low:2}[a.priority] - {high:0,medium:1,low:2}[b.priority]) || (a.due || '9999').localeCompare(b.due || '9999') || b.createdAt.localeCompare(a.createdAt));
}
export function countdown(settings, today = localDate()) {
  const total = Math.max(1, dayIndex(settings.targetDate)-dayIndex(settings.startDate));
  const remaining = dayIndex(settings.targetDate)-dayIndex(today);
  return { remaining, total, elapsed: Math.max(0, Math.min(total, total-remaining)), progress: Math.max(0, Math.min(100, (total-remaining)/total*100)) };
}
export function weekStats(state, start, end) {
  const between = iso => iso && localDate(new Date(iso)) >= start && localDate(new Date(iso)) <= end;
  const tasks = state.tasks.filter(t=>between(t.completedAt));
  const logs = state.logs.filter(l=>l.date>=start && l.date<=end);
  const sessions = state.sessions.filter(s=>between(s.completedAt));
  return { tasks, logs, sessions, minutes:sessions.reduce((n,s)=>n+s.minutes,0) };
}
export function weeks(state) {
  return Array.from({length:3},(_,i)=> { const start=addDays(state.settings.startDate, i*7); const end=addDays(start,6); return { start,end,...weekStats(state,start,end) }; });
}
export function summaryText(state, week) {
  const lines=[`# ${state.settings.project} · 每周摘要`, `${week.start} — ${week.end}`, '', `完成任务 ${week.tasks.length} 项 · 专注 ${week.minutes} 分钟 · 研究日志 ${week.logs.length} 篇`, '', '## 完成的行动', ...(week.tasks.length ? week.tasks.map(t=>`- ${t.title}`) : ['- 暂无已完成任务']), '', '## 研究记录'];
  for(const log of week.logs) { lines.push(`### ${log.date} · ${log.title}`); for(const [key,label] of [['result','仿真 / 结果'],['error','报错'],['blocker','卡点'],['next','下一步']]) if(log[key]) lines.push(`${label}：${log[key]}`); lines.push(''); }
  if(!week.logs.length) lines.push('暂无研究日志。');
  lines.push('', '## 下一步', ...state.tasks.filter(t=>!t.completedAt).slice(0,5).map(t=>`- ${t.title}${t.due ? `（${t.due}）` : ''}`));
  return lines.join('\n');
}
export function remainingMs(timer, now=Date.now()) { return timer ? Math.max(0, timer.endAt === null ? timer.remaining : timer.endAt-now) : FOCUS_MS; }
export function finishTimer(state, now=Date.now()) {
  if(!state.timer || state.timer.endAt===null || remainingMs(state.timer,now)>0) return false;
  const timer=state.timer;
  if(!state.sessions.some(s=>s.id===timer.id)) state.sessions.push({ id:timer.id, taskId:timer.taskId, title:timer.title, minutes:25, completedAt:new Date(timer.endAt).toISOString() });
  state.timer=null;
  return true;
}
const fail=()=>{ throw new Error('备份格式不正确或版本不受支持，当前数据未更改。'); };
const str=(v,n=20000)=>typeof v==='string' && v.length<=n;
const iso=v=>str(v,50) && /^\d{4}-\d{2}-\d{2}T/.test(v) && Number.isFinite(Date.parse(v));
const date=v=>str(v,10) && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(dayIndex(v)) && localDate(new Date(`${v}T12:00:00`))===v;
const unique=items=>new Set(items.map(i=>i?.id)).size===items.length;
export function validateState(s) {
  if(!s || s.schema!==SCHEMA || !Array.isArray(s.tasks) || !Array.isArray(s.logs) || !Array.isArray(s.sessions)) fail();
  if([s.tasks,s.logs,s.sessions].some(a=>a.length>100000 || !unique(a))) fail();
  if(s.tasks.some(t=>!t || !str(t.id,100) || !t.id || !str(t.title,200) || !t.title.trim() || !str(t.note,2000) || !['high','medium','low'].includes(t.priority) || (t.due!==null && !date(t.due)) || !iso(t.createdAt) || (t.completedAt!==null && !iso(t.completedAt)))) fail();
  if(s.logs.some(l=>!l || !str(l.id,100) || !l.id || !date(l.date) || !str(l.title,200) || !l.title.trim() || ['result','error','blocker','next'].some(k=>!str(l[k])) || !iso(l.createdAt))) fail();
  if(s.sessions.some(f=>!f || !str(f.id,100) || !f.id || !str(f.title,200) || (f.taskId!==null && !str(f.taskId,100)) || f.minutes!==25 || !iso(f.completedAt))) fail();
  const c=s.settings;
  if(!c || !date(c.startDate) || !date(c.targetDate) || c.targetDate<c.startDate || !str(c.project,100) || !c.project.trim() || typeof c.reminders!=='boolean' || !Array.isArray(c.times) || c.times.length!==2 || c.times.some(t=>!/^([01]\d|2[0-3]):[0-5]\d$/.test(t))) fail();
  if(s.lastBackupAt!==null && !iso(s.lastBackupAt)) fail();
  const t=s.timer;
  if(t!==null && (!t || !str(t.id,100) || !str(t.title,200) || (t.taskId!==null && !str(t.taskId,100)) || !Number.isFinite(t.remaining) || t.remaining<0 || t.remaining>FOCUS_MS || (t.endAt!==null && (!Number.isFinite(t.endAt) || t.endAt<0)))) fail();
  return structuredClone(s);
}
export function exportBackup(state) { return JSON.stringify({ appId:APP_ID, version:SCHEMA, exportedAt:new Date().toISOString(), data:validateState(state) },null,2); }
export function parseBackup(text) {
  if(text.length>10*1024*1024) throw new Error('备份文件超过 10 MB，请检查文件。');
  let backup; try { backup=JSON.parse(text); } catch { fail(); }
  if(backup?.appId!==APP_ID || backup?.version!==SCHEMA) fail();
  const state=validateState(backup.data);
  state.settings.reminders=false;
  state.timer=null;
  return state;
}
