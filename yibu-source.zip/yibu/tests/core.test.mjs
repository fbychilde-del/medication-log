import test from 'node:test';
import assert from 'node:assert/strict';
import { initialState, addDays, countdown, visibleTasks, weeks, exportBackup, parseBackup, validateState, remainingMs, finishTimer, FOCUS_MS, summaryText } from '../src/core.js';
const date='2026-10-26';
const task=(id,due,priority='medium',completedAt=null)=>({id,title:`task ${id}`,note:'',due,priority,createdAt:'2026-10-26T01:00:00.000Z',completedAt});
test('21-day plan uses local calendar dates across year and leap-day boundaries',()=>{
  const s=initialState(date);assert.equal(s.settings.targetDate,'2026-11-16');assert.equal(countdown(s.settings,date).remaining,21);assert.equal(addDays('2028-02-28',1),'2028-02-29');assert.equal(addDays('2026-12-25',10),'2027-01-04');assert.equal(countdown(s.settings,'2026-11-20').progress,100);
});
test('today includes overdue and undated tasks, excludes future and complete tasks, sorted by priority',()=>{
  const s=initialState(date);s.tasks=[task('future','2026-10-27'),task('today',date),task('overdue','2026-10-25','high'),task('undated',null,'low'),task('done',date,'high','2026-10-26T02:00:00.000Z')];
  assert.deepEqual(visibleTasks(s,'today',date).map(t=>t.id),['overdue','today','undated']);assert.equal(visibleTasks(s,'open',date).length,4);assert.equal(visibleTasks(s,'done',date).length,1);
});
test('backup round-trip retains research evidence and drops device notification consent and timer',()=>{
  const s=initialState(date);s.tasks=[task('one',null)];s.logs=[{id:'log',title:'负面结果',date,result:'误差没有降低\nSNR=5 dB',error:'维度不匹配 <script>',blocker:'不能稳定复现',next:'固定随机种子',createdAt:'2026-10-26T03:00:00.000Z'}];s.settings.reminders=true;s.timer={id:'timer',taskId:'one',title:'专注',remaining:FOCUS_MS,endAt:Date.now()+FOCUS_MS};
  const r=parseBackup(exportBackup(s));assert.deepEqual(r.tasks,s.tasks);assert.deepEqual(r.logs,s.logs);assert.equal(r.settings.reminders,false);assert.equal(r.timer,null);
});
test('backup validation rejects wrong app, unsupported schema, duplicate identifiers and invalid real dates',()=>{
  const s=initialState(date);assert.throws(()=>parseBackup('{}'));assert.throws(()=>parseBackup('{'));assert.throws(()=>validateState({...s,schema:2}));assert.throws(()=>validateState({...s,tasks:[task('same',date),task('same',date)]}));assert.throws(()=>validateState({...s,tasks:[task('bad','2026-02-30')]}));assert.throws(()=>validateState({...s,settings:{...s.settings,times:['29:00','20:00']}}));assert.throws(()=>validateState({...s,logs:[null]}));
});
test('timer accounts for real elapsed time and paused time, completes once at its true end time',()=>{
  const s=initialState(date);s.timer={id:'session',taskId:null,title:'自由专注',remaining:FOCUS_MS,endAt:100000+FOCUS_MS};assert.equal(remainingMs(s.timer,200000),FOCUS_MS-100000);assert.equal(remainingMs({...s.timer,endAt:null,remaining:123456},9999999),123456);assert.equal(finishTimer(s,100001),false);assert.equal(finishTimer(s,9999999),true);assert.equal(s.sessions.length,1);assert.equal(s.sessions[0].completedAt,new Date(100000+FOCUS_MS).toISOString());assert.equal(finishTimer(s,9999999),false);assert.equal(s.sessions.length,1);
});
test('three weekly summaries include real evidence and week-end boundaries',()=>{
  const s=initialState(date);s.tasks=[task('first',date,'high','2026-10-26T01:00:00.000Z'),task('second',date,'high','2026-11-02T01:00:00.000Z')];s.logs=[{id:'log',title:'失败也记录',date:'2026-11-01',result:'',error:'NaN',blocker:'待定位',next:'加断点',createdAt:'2026-11-01T01:00:00.000Z'}];const w=weeks(s);assert.equal(w.length,3);assert.equal(w[0].end,'2026-11-01');assert.equal(w[0].tasks.length,1);assert.equal(w[1].tasks.length,1);assert.equal(w[0].logs.length,1);assert.match(summaryText(s,w[0]),/NaN/);assert.match(summaryText(s,w[0]),/待定位/);
});
