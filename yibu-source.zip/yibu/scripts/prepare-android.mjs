import { spawnSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
const cli=path.resolve('node_modules/@capacitor/cli/bin/capacitor');
function cap(...args) { const result=spawnSync(process.execPath,[cli,...args],{encoding:'utf8'}); process.stdout.write(result.stdout||'');process.stderr.write(result.stderr||'');if(result.error || result.status!==0 || /\[error\]|failed!/i.test((result.stdout||'')+(result.stderr||'')))process.exit(result.status||1); }
if(!existsSync('android'))cap('add','android');
cap('sync','android');
const base='android/app/src/main';
function verifyCopy(src,dst) { for(const item of readdirSync(src,{withFileTypes:true})) {const from=path.join(src,item.name),to=path.join(dst,item.name);if(item.isDirectory())verifyCopy(from,to);else if(!existsSync(to)||!readFileSync(from).equals(readFileSync(to)))throw new Error(`Android assets do not match build: ${item.name}`);} }
verifyCopy('dist',`${base}/assets/public`);
const manifestPath=`${base}/AndroidManifest.xml`;
let manifest=readFileSync(manifestPath,'utf8');
for(const name of ['POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','RECEIVE_BOOT_COMPLETED']) {
  if(!manifest.includes(`android.permission.${name}`))manifest=manifest.replace('</manifest>',`    <uses-permission android:name="android.permission.${name}" />\n</manifest>`);
}
// Explicit export/import replaces automatic OS cloud backup for research data.
manifest=manifest.replace('android:allowBackup="true"','android:allowBackup="false"');
writeFileSync(manifestPath,manifest);
mkdirSync(`${base}/res/drawable`,{recursive:true});
writeFileSync(`${base}/res/drawable/ic_stat_yibu.xml`,`<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24"><path android:strokeColor="#FFFFFFFF" android:strokeWidth="2.5" android:strokeLineCap="round" android:strokeLineJoin="round" android:pathData="M4,19 L10,19 L10,13 L16,13 L16,7 L21,7"/></vector>`);
writeFileSync(`${base}/res/drawable/ic_launcher_foreground.xml`,`<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108"><path android:strokeColor="#FFFFF8ED" android:strokeWidth="7" android:strokeLineCap="round" android:strokeLineJoin="round" android:pathData="M30,67 L46,67 L46,53 L62,53 L62,39 L78,39"/></vector>`);
const background=`${base}/res/values/ic_launcher_background.xml`;
if(existsSync(background))writeFileSync(background,'<resources><color name="ic_launcher_background">#C45D3E</color></resources>');
for(const name of ['ic_launcher','ic_launcher_round'])writeFileSync(`${base}/res/mipmap-anydpi-v26/${name}.xml`,'<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android"><background android:drawable="@color/ic_launcher_background"/><foreground android:drawable="@drawable/ic_launcher_foreground"/></adaptive-icon>');
for(const size of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']) {
  const folder=`${base}/res/mipmap-${size}`;mkdirSync(folder,{recursive:true});
  copyFileSync('public/icons/icon-192.png',`${folder}/ic_launcher.png`);
  copyFileSync('public/icons/icon-192.png',`${folder}/ic_launcher_round.png`);
}
const colors=`${base}/res/values/yibu_colors.xml`;
writeFileSync(colors,'<resources><color name="colorPrimary">#344B3B</color><color name="colorPrimaryDark">#F7F5F0</color><color name="colorAccent">#C45D3E</color><color name="yibu_background">#F7F5F0</color></resources>');
const styles=`${base}/res/values/styles.xml`;
let theme=readFileSync(styles,'utf8');
theme=theme.replace('@drawable/splash','@color/yibu_background');
if(!theme.includes('windowSplashScreenAnimatedIcon'))theme=theme.replace('<style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">','<style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen">\n        <item name="windowSplashScreenBackground">@color/yibu_background</item>\n        <item name="windowSplashScreenAnimatedIcon">@drawable/ic_launcher_foreground</item>\n        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>');
writeFileSync(styles,theme);
console.log('\nAndroid project ready. Open Android Studio with pnpm android:open, or run android/gradlew assembleDebug.');
