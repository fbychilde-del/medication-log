import { readdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
async function walk(dir) { const entries=await readdir(dir,{withFileTypes:true}); const files=[]; for(const e of entries) { const p=path.join(dir,e.name); if(e.isDirectory()) files.push(...await walk(p)); else if(e.name!=='sw.js') files.push(p); } return files; }
const files=await walk('dist');
const hash=createHash('sha256'); for(const f of files) hash.update(await readFile(f));
const version=hash.digest('hex').slice(0,12);
const urls=files.map(f=>'/'+f.replaceAll('\\','/').replace(/^dist\//,''));
await writeFile('dist/sw.js',`const CACHE='yibu-${version}';
const PRECACHE=${JSON.stringify(urls)};
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(PRECACHE))));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil(Promise.all([caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('yibu-')&&k!==CACHE).map(k=>caches.delete(k)))),self.clients.claim()])));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==self.location.origin)return;
 if(event.request.mode==='navigate') {event.respondWith(fetch(event.request).catch(()=>caches.match('/index.html')));return;}
 if(PRECACHE.includes(url.pathname))event.respondWith(caches.match(url.pathname).then(cached=>cached||fetch(event.request)));
});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(async list=>{if(list[0])return list[0].focus();return self.clients.openWindow('/');}));});
`);
console.log(`Offline shell: ${urls.length} files, revision ${version}`);
