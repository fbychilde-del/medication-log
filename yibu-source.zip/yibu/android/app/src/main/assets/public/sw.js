const CACHE='yibu-113c7b72455e';
const PRECACHE=["/assets/index-BqwUwth_.js","/assets/index-CRQEiSD-.css","/assets/web-CSc2s990.js","/assets/web-Dpo2oP0m.js","/assets/web-DuDzBlYF.js","/assets/web-DXMh1RcS.js","/assets/web-qk9HD_js.js","/icon.svg","/icons/icon-192.png","/icons/icon-512.png","/index.html","/manifest.webmanifest"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(PRECACHE))));
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('activate',event=>event.waitUntil(Promise.all([caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('yibu-')&&k!==CACHE).map(k=>caches.delete(k)))),self.clients.claim()])));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==self.location.origin)return;
 if(event.request.mode==='navigate') {event.respondWith(fetch(event.request).catch(()=>caches.match('/index.html')));return;}
 if(PRECACHE.includes(url.pathname))event.respondWith(caches.match(url.pathname).then(cached=>cached||fetch(event.request)));
});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(async list=>{if(list[0])return list[0].focus();return self.clients.openWindow('/');}));});
