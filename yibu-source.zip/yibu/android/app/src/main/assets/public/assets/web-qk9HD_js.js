import{W as n}from"./index-BqwUwth_.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
