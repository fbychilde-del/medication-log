package app.yibu.research;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
