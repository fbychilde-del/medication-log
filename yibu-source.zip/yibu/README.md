# 一步 · 研究行动

中文、Android 优先、离线优先的研究督促工具。每一步，都算数。

## 已实现

- 约 1.65 秒柔和开屏动画；尊重系统“减少动态效果”设置。
- 任务添加、编辑、删除、撤销、完成与重新打开；三档优先级和可选截止日期。
- 今日 / 未完成 / 已完成分类。今日包含已过期、当天到期和未设截止日期的待办，未来任务在“未完成”中。
- 每天两次可配置提醒，时间默认 09:00、20:00。首次由用户开启；不使用羞辱或责备措辞。
- 25 分钟专注，支持暂停、继续、结束；保存绝对结束时间，切换页面和重开后恢复，完整结束后记一次 25 分钟。
- 研究日志：日期、标题、仿真 / 结果、报错、卡点、下一步，可编辑或删除。
- 默认从首次使用起 21 天倒计时；可调整计划名称和日期；按开始日期起三周生成真实每周摘要，可复制或导出 Markdown。
- IndexedDB 本地存储；版本化 JSON 备份、格式验证、恢复数量预览、恢复前快照和撤销恢复。
- PWA 安装清单、192 / 512 图标、带版本的离线缓存与手动更新提示。
- Capacitor Android 工程，本地通知、系统分享导出备份、启动图标与通知图标配置。

## 最快运行

需要 Node.js 22 或更高（本次使用 24.22.1）和 pnpm 11.25.0。

```powershell
cd "你的路径\yibu"
corepack enable
corepack prepare pnpm@11.25.0 --activate
pnpm install --frozen-lockfile
pnpm dev
```

打开控制台显示的网址。开发模式不注册离线缓存，检查生产离线效果请用：

```powershell
pnpm test
pnpm build
pnpm preview --host 127.0.0.1 --port 4173
```

打开 `http://127.0.0.1:4173`，到设置看到“离线资源已缓存”后再断网重开。直接双击 `dist/index.html` 不受支持。

## 安装到 Android 主屏幕

在 Android Chrome 打开已发布的 HTTPS 网址，登录自己的预览账号后，在浏览器菜单选“安装应用”或“添加到主屏幕”。首次保持联网，等待离线资源缓存。数据不会随登录账号自动同步。

PWA 需要 HTTPS 或 localhost。手机通过局域网 HTTP 地址访问开发服务只能做界面预览，通常不能使用完整 PWA 能力。默认发布预览仅限所有者访问。

## Android APK 打包

本次已生成并同步 `android/` 工程。本机未检测到 Android Studio / Java / SDK，改用 GitHub Actions 成功编译了调试 APK：[构建记录](https://github.com/fbychilde-del/medication-log/actions/runs/40270756715)。安装包文件与校验值已核对，**尚未在 Android 真机验证原生通知与后台行为**。

按 [Capacitor 8 官方环境说明](https://capacitorjs.com/docs/getting-started/environment-setup) 准备 Android Studio 2025.2.1 或更高及 Android SDK Platform 36。Android Studio 自带 JDK，本项目生成的 Gradle 配置要求 Java 21。先检查现有环境，避免重复安装。

```powershell
pnpm install --frozen-lockfile
pnpm test
pnpm android:prepare
pnpm android:open
```

`android:prepare` 会构建网页、添加（仅首次）及同步 Android 平台、校验网页复制一致性，再补齐通知权限与图标。重复执行不会重置任务数据。

在 Android Studio 等待 Gradle 同步完成，连接手机调试运行；用菜单 Build → Generate App Bundles or APKs → Generate APKs 生成调试包。也可在已配置 `JAVA_HOME` 和 SDK 路径的终端：

```powershell
cd android
.\gradlew.bat assembleDebug
```

产物：`android/app/build/outputs/apk/debug/app-debug.apk`。调试包可自用。长期升级请保持 `app.yibu.research` 应用 ID 和同一签名密钥；安装新版本前备份，**不要先卸载旧版**。正式发行用 Android Studio 生成签名 APK，妥善保存密钥，并递增 `android/app/build.gradle` 的 `versionCode`。

不想在电脑安装 Android 环境，可把本项目作为独立仓库上传到你自己的 GitHub，手动运行随附的 `.github/workflows/android.yml`，下载 `yibu-debug-apk` 产物。本次成功构建使用现有仓库独立分支中的 `.github/workflows/yibu-android.yml`，会先解压 `yibu-source.zip`。流程只构建源码，不包含你的本地研究记录。

Android 环境准备使用 `android-actions/setup-android@v4` 和 `platform-tools`；旧版默认请求的 `tools` 包已停止提供，会导致失败。本次第一轮构建因此失败，修正后第二轮构建成功。GitHub 构建环境固定为 Ubuntu 24.04、Java 21、Node 24、SDK 36。

## 提醒能力与实机验收

Android 版用 [Capacitor Local Notifications](https://capacitorjs.com/docs/apis/local-notifications)；无需服务器、账号或网络。首次保存开启设置时请求 Android 13+ 通知权限。未授权时不声称安排成功。Android 12+ 可在“精确提醒设置”主动授权；未授权时使用系统允许的非精确提醒，可能延迟。勿依赖它作为关键日程唯一提醒。设备省电、强制停止、厂商后台策略也可能延迟或阻止提醒。

网页 / PWA 版：每天两次提醒只在页面打开且可见时检查。系统测试通知需要浏览器通知权限；**关掉浏览器或锁屏后不提供可靠的后台定时提醒**。专注时间仍按真实经过时间恢复，但浏览器关闭时没有准点结束通知。

安装 APK 后请实际验证：

1. 拒绝通知权限时，设置提示未授权；授权后能收到测试通知。
2. 将两个提醒改为不同的近期时间，锁屏 / 断网后检查触发；检查精确权限开启与关闭两种情况。
3. 重启手机后检查日提醒恢复；在厂商省电模式下检查是否要允许后台运行。
4. 专注暂停、切后台、重开、到时各完成一次；确认不会重复计数。
5. 导出备份到系统“文件”，再从文件恢复；验证任务、日志原文、已完成状态和专注记录数量。

通知不会在未使用 App 时自行获权；从备份迁移时关闭提醒、清除正在运行的计时，需在新设备重新开启。

## 数据与长期使用

无账号系统、云数据库、第三方字体、分析统计或研究内容上传。网站托管服务仍会处理提供页面所必需的访问请求。Android 禁用自动云备份，主动导出的 JSON 包含完整研究文字，建议每周保存到个人安全位置。

记录按当前设备的本地日期归类，提醒跟随设备时区。三周摘要始终为从计划开始起的三个 7 日区间；调整发表日期只影响倒计时。跨出三周后任务、日志和专注仍可继续使用，历史记录保留；可调整计划开始日期查看新的三周。

当前 MVP 不包含附件、账号同步、跨设备实时同步、多个并行项目、自动邮件或 AI 生成总结。

同一浏览器网址尽量只开一个编辑窗口，支持 Web Locks 的环境会阻止第二个窗口写入。无痕模式、清理网站数据、换域名、卸载 App 都可能让记录丢失。持久存储保护可申请，不能代替外部备份。浏览器版与 APK 存储独立，迁移请使用备份。

备份上限 10 MB；恢复为整体替换，界面会提示，恢复前快照只保留最近一次，后续恢复会覆盖该快照。任务 / 日志删除后可用短暂的“撤销”按钮找回，超过时间需要从外部备份找回。浏览器导出状态只表示发起下载，Android 只表示已打开系统分享，请自行确认文件真正保存成功。

## 结构

```text
src/core.js                  日期、分类、摘要、计时与备份校验
src/storage.js               IndexedDB 原子保存、恢复快照与编辑锁
src/native.js                平台通知、权限、分享导出
src/main.js / style.css      中文界面与操作
public/                      PWA 清单与图标
scripts/build-sw.mjs         构建后生成版本化离线缓存
scripts/prepare-android.mjs  Android 同步与配置
tests/core.test.mjs          核心数据规则测试
android/                     Android Studio 工程
```

完整测试和本次验证结果见 `VALIDATION.md`。
